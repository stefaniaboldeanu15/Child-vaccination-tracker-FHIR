package org.prt.prtvaccinationtracking_fhir.dto.relatedPerson;

public class RelatedPersonLoginResponseDTO {

    private String accessToken;
    private String patientId;
    private String firstName;
    private String lastName;

    public RelatedPersonLoginResponseDTO() {
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
