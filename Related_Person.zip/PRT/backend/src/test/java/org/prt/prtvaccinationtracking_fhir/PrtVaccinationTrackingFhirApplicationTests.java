package org.prt.prtvaccinationtracking_fhir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrtVaccinationTrackingFhirApplicationTests {

    @Test
    void contextLoads() {
    }

}
